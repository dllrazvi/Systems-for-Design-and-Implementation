import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface RaceHistory {
  _id: string;
  DriverName?: string;
  DriverId?: string;
  RaceName: string;
  Year: number;
  Points: number;
}

const DeleteDriverRaceHistoryForm = () => {
  const [history, setHistory] = useState<RaceHistory[]>([]);
  const [selectedId, setSelectedId] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/api/driverracehistory')
      .then(res => setHistory(res.data))
      .catch(err => console.error('Error fetching history:', err));
  }, []);

  const handleDelete = async () => {
    if (!selectedId) {
      alert('Select a race history entry to delete.');
      return;
    }

    try {
      await axios.delete(`http://localhost:5000/api/driverracehistory/${selectedId}`);
      alert('Deleted successfully!');
      setHistory(history.filter((item) => item._id !== selectedId));
      setSelectedId('');
    } catch (error) {
      console.error('Error deleting history:', error);
      alert('Error deleting entry');
    }
  };

  return (
    <div>
      <h2>Delete Driver Race History</h2>
      <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)}>
        <option value="">Select Entry</option>
        {history.map((item) => (
          <option key={item._id} value={item._id}>
            {`${item.RaceName} (${item.Year}) - ${item.Points}p - ${item.DriverName || item.DriverId}`}
          </option>
        ))}
      </select>
      <button onClick={handleDelete}>Delete</button>
    </div>
  );
};

export default DeleteDriverRaceHistoryForm;
