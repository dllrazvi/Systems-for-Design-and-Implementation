import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface Driver {
  _id: string;
  DriverName: string;
}

const AddDriverRaceHistoryForm = () => {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [selectedDriverId, setSelectedDriverId] = useState('');
  const [raceName, setRaceName] = useState('');
  const [year, setYear] = useState('');
  const [points, setPoints] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/api/f1drivers')
      .then(res => setDrivers(res.data))
      .catch(err => console.error('Error fetching drivers:', err));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDriverId || !raceName || !year || !points) {
      alert("All fields are required");
      return;
    }

    try {
      await axios.post('http://localhost:5000/api/driverracehistory', {
        DriverId: selectedDriverId,
        RaceName: raceName,
        Year: parseInt(year),
        Points: parseInt(points)
      });
      alert('Race history added!');
    } catch (error) {
      console.error('Error adding race history:', error);
      alert('Error adding race history');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Driver Race History</h2>

      <label>Driver:</label>
      <select value={selectedDriverId} onChange={(e) => setSelectedDriverId(e.target.value)}>
        <option value="">Select Driver</option>
        {drivers.map((driver) => (
          <option key={driver._id} value={driver._id}>{driver.DriverName}</option>
        ))}
      </select>

      <label>Race Name:</label>
      <input type="text" value={raceName} onChange={(e) => setRaceName(e.target.value)} />

      <label>Year:</label>
      <input type="number" value={year} onChange={(e) => setYear(e.target.value)} />

      <label>Points:</label>
      <input type="number" value={points} onChange={(e) => setPoints(e.target.value)} />

      <button type="submit">Add</button>
    </form>
  );
};

export default AddDriverRaceHistoryForm;
